package com.lfl.entity;

public class Exam2 {
	private Integer e_id;
	private Integer s_i;
	private String e_name;
	private String e_starttime;
	private String e_stoptime;
	private String q_name;
	private String q_path;
	private String s_fname;
	private String s_fpath;
	private String s_score;
	private String s_comment;
	//构造方法，域
	
	public Integer getE_id() {
		return e_id;
	}
	public String getS_fname() {
		return s_fname;
	}
	public void setS_fname(String s_fname) {
		this.s_fname = s_fname;
	}
	public String getS_fpath() {
		return s_fpath;
	}
	public void setS_fpath(String s_fpath) {
		this.s_fpath = s_fpath;
	}
	public void setE_id(Integer e_id) {
		this.e_id = e_id;
	}
	public String getE_name() {
		return e_name;
	}
	public void setE_name(String e_name) {
		this.e_name = e_name;
	}
	public String getE_starttime() {
		return e_starttime;
	}
	public void setE_starttime(String e_starttime) {
		this.e_starttime = e_starttime;
	}
	public String getE_stoptime() {
		return e_stoptime;
	}
	public void setE_stoptime(String e_stoptime) {
		this.e_stoptime = e_stoptime;
	}
	public String getQ_name() {
		return q_name;
	}
	public void setQ_name(String q_name) {
		this.q_name = q_name;
	}
	public String getQ_path() {
		return q_path;
	}
	public void setQ_path(String q_path) {
		this.q_path = q_path;
	}
	public Integer getS_i() {
		return s_i;
	}
	public void setS_i(Integer s_i) {
		this.s_i = s_i;
	}
	public String getS_score() {
		return s_score;
	}
	public void setS_score(String s_score) {
		this.s_score = s_score;
	}
	public String getS_comment() {
		return s_comment;
	}
	public void setS_comment(String s_comment) {
		this.s_comment = s_comment;
	}


	
}

package com.lfl.entity;

public class Global {
	private Integer g_id;
	private Integer task_interval;
	private Integer record_number;
	private Integer max_advance_time;
	private Integer min_file_size;
	private Integer max_file_size;
	private Integer teacher_can_clean;
   
	//构造方法，域
	public Integer getTask_interval() {
		return task_interval;
	}
	public void setTask_interval(Integer task_interval) {
		this.task_interval = task_interval;
	}
	public Integer getRecord_number() {
		return record_number;
	}
	public void setRecord_number(Integer record_number) {
		this.record_number = record_number;
	}
	public Integer getMax_advance_time() {
		return max_advance_time;
	}
	public void setMax_advance_time(Integer max_advance_time) {
		this.max_advance_time = max_advance_time;
	}
	public Integer getMin_file_size() {
		return min_file_size;
	}
	public void setMin_file_size(Integer min_file_size) {
		this.min_file_size = min_file_size;
	}
	public Integer getMax_file_size() {
		return max_file_size;
	}
	public void setMax_file_size(Integer max_file_size) {
		this.max_file_size = max_file_size;
	}
	public Integer getTeacher_can_clean() {
		return teacher_can_clean;
	}
	public void setTeacher_can_clean(Integer teacher_can_clean) {
		this.teacher_can_clean = teacher_can_clean;
	}
	public Integer getG_id() {
		return g_id;
	}
	public void setG_id(Integer g_id) {
		this.g_id = g_id;
	}
	

}
